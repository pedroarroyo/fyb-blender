from . import keymap

def register():
    keymap.register()

def unregister():
    keymap.unregister()